#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

/* ---------------------------------------------------------------
   G.711 μ-law → Linear PCM decoder converts an 8-bit μ-law sample into a 16-bit
   signed PCM value
   --------------------------------------------------------------- */

#define MU_SIGN      0x80
#define MU_QUANT     0x0F
#define MU_SEGMENT   0x70
#define MU_SHIFT     4
#define MU_BIAS      0x84

static int16_t ulaw_to_pcm(int8_t code)
{
    /* μ-law bytes are stored inverted */
    uint8_t u = ~code;

    /* Extract quantization bits and add bias */
    int16_t value = ((u & MU_QUANT) << 3) + MU_BIAS;

    /* Apply segment scaling */
    value <<= ((u & MU_SEGMENT) >> MU_SHIFT);

    /* Restore sign and remove bias */
    return (u & MU_SIGN) ? (MU_BIAS - value) : (value - MU_BIAS);
}

/* ---------------------------------------------------------------
   Minimal WAV header for 16-bit PCM mono audio
   8 kHz sample rate standard for µ-law telephony audio
   --------------------------------------------------------------- */

static uint8_t wav_header[44] = {
    'R','I','F','F',
    0,0,0,0,            /* file size placeholder */

    'W','A','V','E',
    'f','m','t',' ',
    16,0,0,0,           /* PCM fmt chunk */
    1,0,                /* PCM format tag */
    1,0,                /* 1 channel */
    0x40,0x1F,0x00,0x00,/* 8000 Hz */
    0x80,0x3E,0x00,0x00,/* byte rate = 8000 * 2 */
    2,0,                /* block align */
    16,0,               /* bits per sample */

    'd','a','t','a',
    0,0,0,0             /* data size placeholder */
};

int main(void)
{
    const char *input_name  = "Au8A_eng_m1.wav";
    const char *output_name = "decoded_pcm_output_Au8A.wav";

    FILE *fin = fopen(input_name, "rb");
    if (!fin) {
        fprintf(stderr, "Failed to open input file.\n");
        return 1;
    }

    FILE *fout = fopen(output_name, "wb+");
    if (!fout) {
        fprintf(stderr, "Failed to open output file.\n");
        fclose(fin);
        return 1;
    }


    fwrite(wav_header, sizeof(wav_header), 1, fout);

    /* Skip original file's WAV header */
    fseek(fin, 44, SEEK_SET);

    uint8_t encoded_byte;
    int16_t pcm_value;
    uint32_t pcm_data_bytes = 0;

    /* Read 1 μ-law byte → decode → write 2 PCM bytes */
    while (fread(&encoded_byte, 1, 1, fin) == 1)
    {
        pcm_value = ulaw_to_pcm((int8_t)encoded_byte);
        fwrite(&pcm_value, sizeof(pcm_value), 1, fout);
        pcm_data_bytes += sizeof(pcm_value);
    }

    /* -----------------------------------------------------------
       Patch the WAV header with correct RIFF and data sizes
       ----------------------------------------------------------- */

    uint32_t riff_size = pcm_data_bytes + 36;

    fseek(fout, 4, SEEK_SET);
    fwrite(&riff_size, sizeof(riff_size), 1, fout);

    fseek(fout, 40, SEEK_SET);
    fwrite(&pcm_data_bytes, sizeof(pcm_data_bytes), 1, fout);

    fclose(fin);
    fclose(fout);

    printf("μ-law decoding completed.\n");
    return 0;
}
